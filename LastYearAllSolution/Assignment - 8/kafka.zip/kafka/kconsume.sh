/usr/hdp/current/kafka-broker/bin/kafka-console-consumer.sh --zookeeper sandbox.hortonworks.com:2181 --bootstrap-server sandbox.hortonworks.com:6667 --topic $1 --from-beginning


