/usr/hdp/current/kafka-broker/bin/kafka-topics.sh --list --zookeeper sandbox.hortonworks.com:2181

