frc = spark.read.csv('/user/cs595/foodratings.txt')
frc.show()
frc.printSchema()

