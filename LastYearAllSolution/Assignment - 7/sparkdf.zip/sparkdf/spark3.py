peoplec = spark.read.csv('/user/cs595/people.csv')
peoplec.show()
peoplec.printSchema()

