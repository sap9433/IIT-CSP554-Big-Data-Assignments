fpc = spark.read.csv('/user/cs595/foodplaces.txt')
fpc.show()
fpc.printSchema()

